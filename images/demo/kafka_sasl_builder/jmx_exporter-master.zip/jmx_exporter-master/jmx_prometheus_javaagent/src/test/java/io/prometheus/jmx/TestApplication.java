package io.prometheus.jmx;

import java.io.IOException;

public class TestApplication {
    public static void main(String[] args) throws IOException {
        System.out.println();
        System.out.flush();
        System.in.read();
        System.exit(0);
    }
}
